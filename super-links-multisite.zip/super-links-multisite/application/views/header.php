<?php
if (!defined('ABSPATH')) {
    die('You are not authorized to access this');
}
?>

<div class="super-links-header">
    <img src="<?=SUPER_LINKS_IMAGES_URL?>/logo-super-links-4.png" class="img-fluid super-links-logo">
</div>